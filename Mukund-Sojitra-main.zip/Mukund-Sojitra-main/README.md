# **Aspiring Data Scientist**

## Seeking a challenging role at a reputed organization to utilize my analytical skills that can contribute to the company’s growth as well as enhance my knowledge by exploring new things.
